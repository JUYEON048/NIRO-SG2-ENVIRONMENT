^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pointgrey_camera_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.15.1 (2022-01-12)
-------------------
* Added xacro: to tag calling bumblebee2 xacro, required in noetic
* Contributors: Luis Camero

0.15.0 (2020-11-05)
-------------------

0.14.1 (2020-05-05)
-------------------

0.14.0 (2020-04-03)
-------------------
* Fixed warnings about inconsistent namespace redefinitions for xmlns:xacro.
* Contributors: Tony Baltovski

0.13.4 (2017-10-26)
-------------------

0.13.3 (2017-10-03)
-------------------

0.13.2 (2017-09-28)
-------------------

0.13.1 (2017-04-19)
-------------------

0.13.0 (2017-03-17)
-------------------

0.12.2 (2016-09-30)
-------------------

0.12.1 (2015-11-06)
-------------------
* Added description for bumblebee2 and flea3.
* Contributors: Tony Baltovski

