# Webcam parsing

### Installing libraries

- 참고 : http://wiki.ros.org/velodyne/Tutorials/Getting%20Started%20with%20the%20Velodyne%20VLP16

- Installing ROS dependencies
~~~
$ sudo apt-get install ros-kinetic-velodyne
~~~

- Installing the VLP16 driver (이건 이미 폴더에 있으니까 안해도 됨 - VLP16 처음부터 시작하려면 진행)
~~~
$ cd ~/LGIT_Auto_Parking/MI_Vehicle/src/ && git clone https://github.com/ros-drivers/velodyne.git
$ cd ..
$ rosdep install --from-paths src --ignore-src --rosdistro kinetic -y
$ cm_mi
~~~



### How to run

- VLP16 한개만 실행 할 때
~~~
$ roslaunch velodyne_pointcloud VLP16_points.launch
~~~
> < 참고 사항 >
>
> - 컴퓨터 고정 IP = 192.168.1.100
> - velodyne IP = 192.168.1.202~204 (L:202, R:203, F:204)
>



- VLP16 두개 실행 할 때
~~~
$ roslaunch velodyne_pointcloud VLP16_points_multi.launch
~~~
> < 참고 사항 >
>
> - 컴퓨터 고정 IP = 192.168.1.100
> - Left velodyne IP = 192.168.1.202
> - Right velodyne IP = 192.168.1.203
>
